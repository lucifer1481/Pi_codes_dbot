#ifndef DIFFDRIVE_ARDUINO_REAL_ROBOT_H
#define DIFFDRIVE_ARDUINO_REAL_ROBOT_H

#include <cstring>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"

#include <hardware_interface/handle.hpp>
#include <hardware_interface/hardware_info.hpp>
#include <hardware_interface/system_interface.hpp>
#include <rclcpp_lifecycle/state.hpp>
#include <hardware_interface/types/hardware_interface_return_values.hpp>

#include "config.h"
#include "wheel.h"
#include "arduino_comms.h"

using hardware_interface::CallbackReturn;
using hardware_interface::return_type;

namespace diffdrive_arduino
{

class DiffDriveArduino : public hardware_interface::SystemInterface
{


public:
  DiffDriveArduino();

  CallbackReturn on_init(const hardware_interface::HardwareInfo & info) override;

  std::vector<hardware_interface::StateInterface> export_state_interfaces() override;

  std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

  CallbackReturn on_activate(const rclcpp_lifecycle::State & previous_state) override;

  CallbackReturn on_deactivate(const rclcpp_lifecycle::State & previous_state) override;

  return_type read(const rclcpp::Time & time, const rclcpp::Duration & period) override;

  return_type write(const rclcpp::Time & time, const rclcpp::Duration & period) override;



private:

  Config cfg_;
  ArduinoComms arduino_;
  // Relay / buzzer support
  rclcpp::Node::SharedPtr relay_node_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr relay_sub_;
  bool relay_state_ = false;
  bool last_relay_state_ = false;
  Wheel l_wheel_;
  Wheel r_wheel_;

  rclcpp::Logger logger_;

  std::chrono::time_point<std::chrono::system_clock> time_;
  
};
} // namespace diffdrive_arduino

#endif // DIFFDRIVE_ARDUINO_REAL_ROBOT_H